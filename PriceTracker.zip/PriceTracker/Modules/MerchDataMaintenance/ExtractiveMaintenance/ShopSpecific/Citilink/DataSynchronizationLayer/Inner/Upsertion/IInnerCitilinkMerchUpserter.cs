﻿using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.Models;

namespace PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.DataSynchronizationLayer.Upsertion
{
    public interface IInnerCitilinkMerchUpserter
    {
        void EnqueueForUpsertion(CitilinkMerchParsingDto dto);
        Task CompleteAsync();
    }
}
