﻿using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.Models.Node;

namespace PriceTracker.Modules.Repository.Entities.Process.ShopSpecific.Extraction.CatalogTree
{
    public class CitilinkCatalogBranchEntity : BaseEntity
    {
        public CitilinkCatalogBranchEntity(string url,
            bool descendantsProcessed, CitilinkNodeAugmentationState 
            augmentationState, CitilinkNodeType nodeType, int id = default)
            : base(id)
        {
            NodeType = nodeType;
            Url = url;
            DescendantsProcessed = descendantsProcessed;
        }

        public CitilinkCatalogBranchEntity(string url,
            List<CitilinkCatalogBranchEntity> children,
            bool descendantsProcessed, CitilinkNodeAugmentationState
            augmentationState, CitilinkNodeType nodeType, int id = default)
            : this(url, descendantsProcessed,
                  augmentationState, nodeType, id)
        {
            Children = children;
        }

        public string Url { get; set; }
        public List<CitilinkCatalogBranchEntity> Children
        { get; set; }

        public bool DescendantsProcessed { get; set; }

        public CitilinkNodeAugmentationState AugmentationState { get; set; }
        public CitilinkNodeType NodeType { get; set; }

    }
}
