﻿using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.Models.Node;

namespace PriceTracker.Core.Models.Process.ShopSpecific.Citilink.ExtractionState.CatalogTree
{
    public record CitilinkBranch : BaseDto
    {
        public int Id;
        // Url сопоставляется дефолтному ScrapeTarget
        public string Url;
        public CitilinkBranch? Parent;
        public int? ParentId;
        public List<CitilinkBranch> Children;
        public bool DescendantsProcessed;
        public CitilinkNodeAugmentationState AugmentationState;
        public CitilinkNodeType NodeType;
        /*
        public enum CitilinkNodeAugmentationState
        {
            Processed,
            PartiallyProcessed_TypeIsKnown,
            PartiallyProcessed_TypeIsUnknown,
            Unprocessed
        }

        public enum CitilinkMerchNodeScrapeTargetsAugmentationState
        {
            NotAugmented,
            OneJsonTargetPresent,
            AllTargetsPresent
        }
        */

        public CitilinkBranch(int id, string url, List<CitilinkBranch> children,
             bool descendantsProcessed, CitilinkNodeType nodeType,
             CitilinkNodeAugmentationState augmentationState, CitilinkBranch? parent = null,
            int? parentId = null)
        {
            Id = id;
            Url = url;
            Children = children;
            DescendantsProcessed = descendantsProcessed;
            NodeType = nodeType;
            AugmentationState = augmentationState;
            Parent = parent;
            ParentId = parentId;
        }

        public CitilinkBranch DeepClone()
        {
            return new CitilinkBranch(Id, Url, Children.Select(c => c.DeepClone()).ToList(),
                DescendantsProcessed, NodeType, AugmentationState, Parent, ParentId);
        }
    }
}
