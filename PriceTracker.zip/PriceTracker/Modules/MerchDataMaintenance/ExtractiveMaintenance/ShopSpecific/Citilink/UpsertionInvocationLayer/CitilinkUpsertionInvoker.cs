﻿using PriceTracker.Modules.MerchDataMaintenance.Adapters;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.CoordinationLayer;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.DataSynchronizationLayer.Pipeline;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.Models;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.Models.Node;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.ParsingLayer.Models;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.ScrapingLayer.Inner;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.UpsertionInvocationLayer.Models.Policies.PolicyEnforcersProvider;

namespace PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.UpsertionInvocationLayer
{



    public class CitilinkUpsertionInvoker : ICitilinkUpsertionInvoker
    {
        private readonly ICitilinkDataAugmenter _dataSynchronizer;
        private readonly ICitilinkCatalogTreeRepositoryAdapter _treeRepository;
        private readonly ICitilinkPolicyEnforcersContextfulProvider _enforcersProvider;

        // Логгер не внедрен пока-что... TODO!
        private readonly ILogger? _logger;

        public CitilinkUpsertionInvoker(ICitilinkDataAugmenter dataSynchronizer,
            ICitilinkCatalogTreeRepositoryAdapter treeRepository,
            ICitilinkPolicyEnforcersContextfulProvider enforcersProvider)
        {
            _dataSynchronizer = dataSynchronizer;
            _treeRepository = treeRepository;
            _enforcersProvider = enforcersProvider;
        }


        /// <summary>
        /// Что входит в частичный цикл? Будем считать предподготовку и заканчивание задачами основного цикла.
        /// </summary>
        /// <param name="maxRequests"></param>
        /// <returns></returns>
        public async Task<PartialCycleState> ExecutePartialCycleAsync
            (CitilinkEnforcersSharedContext cycleQuota)
        {
            // TODO: разобраться с соответствием имени класса и объекта входного аргумента
            // в функцию - её назначению. Разрулить и разделить, или упростить? Или оба?


            _enforcersProvider.SetActiveContext(cycleQuota);
            while (true)
            {
                // todo: можем ли мы так лихо обращаться к самому репозиторию отсюда (или его адаптеру) - без
                // прослоек без посредников?

                
                var node = await _treeRepository.GetAnyUnprocessedNodeAsync();
                if (node == null)
                {
                    // Если GetAnyUnprocessed возвращает null ток когда кончаются необойденные узлы - это верно.
                    // todo: зафиксировать в юнит-тестах сие поведение? hmm...
                    return PartialCycleState.FullCompleted;
                }

                var postProcessingOrder = await FullyProcessNode(node);
                switch (postProcessingOrder)
                {
                    case PostHandlingActions.None_Succcess:
                        continue;
                        break;

                    case PostHandlingActions.PartialCycle_ExpectedCooldown or 
                    PostHandlingActions.PartialCycle_UnexpectedCooldown:
                        return PartialCycleState.PartialCompleted;

                    case PostHandlingActions.Retry:
                        continue;
                        break;

                    default:
                        throw new NotImplementedException();
                        break;
                }
            }
        }


        private async Task<PostHandlingActions> FullyProcessNode(CitilinkNode node)
        {

            if (node.NodeType == CitilinkNodeType.Unknown)
            {
                var state = await ProcessUntilTypeDiscovered(node);
                if (state != PostHandlingActions.None_Succcess)
                    return state;
            }

            switch (node.NodeType)
            {
                case CitilinkNodeType.MerchCatalog:
                    return await CompleteProcessingMerchCatalogNode(node);
                    break;
                case CitilinkNodeType.RootCatalog or CitilinkNodeType.CatalogsCatalog:
                    return await CompleteProcessingRootOrCatalogsCatalogNode(node);
                    break;
                case CitilinkNodeType.Unknown:
                    throw new InvalidOperationException();
                    break;
                default:
                    throw new InvalidOperationException();
                    break;
            }
        }

        private async Task<PostHandlingActions> ProcessUntilTypeDiscovered(CitilinkNode node)
        {
            while(node.NodeType == CitilinkNodeType.Unknown)
            {
                var noErrors = await ProcessUnknownTypeNode(node);
                if (noErrors != PostHandlingActions.None_Succcess
                    && noErrors != PostHandlingActions.Retry)
                {
                    return noErrors;
                }
            }
            return PostHandlingActions.None_Succcess;
        }


        private async Task<PostHandlingActions> ProcessUnknownTypeNode(CitilinkNode node)
        {
            // Проверка входных данных на допустимость
            var type = node.NodeType;
            var state = node.AugmentationState;
            if (type != CitilinkNodeType.Unknown)
                throw new ArgumentException();
            if (state == CitilinkNodeAugmentationState.Processed
                || state == CitilinkNodeAugmentationState.PartiallyProcessed_TypeIsKnown)
                throw new InvalidOperationException();
            // Проверка входных данных на допустимость закончена

            var metaData = await _dataSynchronizer.AugmentNodeDataAsync(node, _enforcersProvider);
            if (StateIndicatesFailure(metaData.DataSyncMetadata.State))
            {
                return HandleError(metaData);
            }
            else
                return PostHandlingActions.None_Succcess;
        }

        private static bool StateIndicatesFailure(CitilinkNodeAugmenterAugmentationState state)
        {
            switch (state)
            {
                case CitilinkNodeAugmenterAugmentationState.Failure_PreviousLayer:
                    return true;
                default:
                    return false;
            }
        }

        

        private async Task<PostHandlingActions> CompleteProcessingMerchCatalogNode(CitilinkNode node)
        {
            var type = node.NodeType;
            var state = node.AugmentationState;
            if (type != CitilinkNodeType.MerchCatalog || state == CitilinkNodeAugmentationState.Processed
                || state == CitilinkNodeAugmentationState.Unprocessed)
                throw new ArgumentException();

            while (true) 
            {
                if (node.LocationsList.Any(t => !t.IsProcessed))
                {
                    var metadata = await _dataSynchronizer.AugmentNodeDataAsync(node, _enforcersProvider);
                    if (StateIndicatesFailure(metadata.DataSyncMetadata.State))
                    {
                        var actions = HandleError(metadata);
                        switch (actions)
                        {
                            case PostHandlingActions.None_Succcess:
                                break;

                            case PostHandlingActions.PartialCycle_ExpectedCooldown or
                            PostHandlingActions.PartialCycle_UnexpectedCooldown:
                                return actions;

                            case PostHandlingActions.Retry:
                                continue;
                                break;
                        }
                        return actions;
                    }
                }
                else if(node.MerchNodeScrapeTargetsAugmentationState ==
                CitilinkMerchNodeScrapeTargetsAugmentationState.AllTargetsPresent)
                {
                    node.AugmentationState = CitilinkNodeAugmentationState.Processed;
                    return PostHandlingActions.None_Succcess;
                }
                else
                {
                    throw new InvalidOperationException();
                }
            }
        }

        private async Task<PostHandlingActions> CompleteProcessingRootOrCatalogsCatalogNode(CitilinkNode node)
        {
            var type = node.NodeType;
            var state = node.AugmentationState;
            if ((type != CitilinkNodeType.CatalogsCatalog && type != CitilinkNodeType.RootCatalog) 
                || state == CitilinkNodeAugmentationState.Processed
                || state == CitilinkNodeAugmentationState.Unprocessed)
                throw new ArgumentException();

            while (node.LocationsList.Any(st => !st.IsProcessed))
            {
                var metadata = await _dataSynchronizer.AugmentNodeDataAsync(node, _enforcersProvider);
                if (StateIndicatesFailure(metadata.DataSyncMetadata.State))
                {
                    // TODO: DRY violation with actions = , switch (actions)
                    var actions = HandleError(metadata);
                    switch (actions)
                    {
                        case PostHandlingActions.None_Succcess:
                            break;

                        case PostHandlingActions.PartialCycle_ExpectedCooldown or 
                        PostHandlingActions.PartialCycle_UnexpectedCooldown:
                            return actions;

                        case PostHandlingActions.Retry:
                            continue;
                            break;
                    }
                }
            }

            node.AugmentationState = CitilinkNodeAugmentationState.Processed;
            return PostHandlingActions.None_Succcess;
        }



        protected enum PostHandlingActions { None_Succcess, PartialCycle_ExpectedCooldown,
            PartialCycle_UnexpectedCooldown, Retry,
        };
        // Make it so it would be returning commands on further actions? Or not...
        private PostHandlingActions HandleError(CitilinkExecutionMetadata metadata)
        {
            var dataSyncStatus = metadata.DataSyncMetadata.State;
            var parsingStatus = metadata.ParseMetadata.State;
            var scrapingStatus = metadata.ScrapeMetadata.CompletionState;

            switch (dataSyncStatus, parsingStatus, scrapingStatus)
            {
                case (CitilinkNodeAugmenterAugmentationState.Success, _, _):
                    throw new InvalidOperationException();

                case (CitilinkNodeAugmenterAugmentationState.Failure_PreviousLayer,
                    ParseCompletionState.Failure_PreviousLayer, _):
                    return HandleScrapingError(metadata.ScrapeMetadata);
                    break;

                case (CitilinkNodeAugmenterAugmentationState.Failure_PreviousLayer, _, _):
                    return HandleParsingError(metadata.ParseMetadata);
                    break;

                default:
                    return HandleDataSyncError(metadata.DataSyncMetadata);
                    break;
            }
        }
        private PostHandlingActions HandleDataSyncError(CitilinkNodeAugmentMetadata metadata)
        {
            throw new NotImplementedException("Когда писали метод - ошибок в Augment слое не было");
        }
        private PostHandlingActions HandleParsingError(CitilinkParseMetadata metadata)
        {
            switch (metadata.State)
            {
                case ParseCompletionState.Success or
                    ParseCompletionState.Failure_PreviousLayer:
                    throw new ArgumentException();

                case ParseCompletionState.Unsuccess_UnknownParsable:
                    _logger?.LogWarning($"На вход парсера было подано что-то неожиданное.");
                    return PostHandlingActions.Retry;
                    break;

                default:
                    // Точно NotImplemented нужно в неучтенных кейсах?
                    throw new NotImplementedException();
                    break;
            }
        }
        private PostHandlingActions HandleScrapingError(CitilinkScrapeMetadata metadata)
        {
            switch (metadata.CompletionState)
            {
                case ScrapeCompletionState.Success:
                    throw new ArgumentException();
                    break;

                case ScrapeCompletionState.StoppedAsPolicyBudgetsReached:
                    _logger?.LogInformation($"");
                    return PostHandlingActions.PartialCycle_ExpectedCooldown;
                    break;

                case ScrapeCompletionState.UnallowedStatus:
                    _logger?.LogWarning($"");
                    return PostHandlingActions.Retry;
                    break;

                default:
                    throw new NotImplementedException();
            }
        }
    }
}
