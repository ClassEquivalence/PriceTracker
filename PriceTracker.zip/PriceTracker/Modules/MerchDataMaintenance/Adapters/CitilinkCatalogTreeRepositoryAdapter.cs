﻿using PriceTracker.Core.Models.Process.ShopSpecific.Citilink.ExtractionState;
using PriceTracker.Core.Models.Process.ShopSpecific.Citilink.ExtractionState.CatalogTree;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.Models.Node;
using PriceTracker.Modules.Repository.Facade.Citilink;

namespace PriceTracker.Modules.MerchDataMaintenance.Adapters
{
    public class CitilinkCatalogTreeRepositoryAdapter : ICitilinkCatalogTreeRepositoryAdapter
    {
        ICitilinkMiscellaneousRepositoryFacade _repositoryFacade;
        private const string mainCatalogUrl = "https://www.citilink.ru/catalog/";
        public CitilinkCatalogTreeRepositoryAdapter(
            ICitilinkMiscellaneousRepositoryFacade repository)
        {
            _repositoryFacade = repository;
        }

        public async Task AppendBranchesAsync(CitilinkNode parent, 
            List<CitilinkScrapeTarget> descendants)
        {
            var state = _repositoryFacade.Provide();
            var parentBranch = state.CachedUrls.GetAllBranches()
                .Single(b => b.Url == parent.DefaultLocation.Url);

            var targetsAsBranches = descendants.Select(st => new CitilinkBranch(default, st.Url,
                [], false, CitilinkNodeType.Unknown, CitilinkNodeAugmentationState.Unprocessed,
                parentBranch, parentBranch.Id));
            parentBranch.Children.AddRange(targetsAsBranches);

            _repositoryFacade.Save(state);
        }

        public async Task<CitilinkNode?> GetAnyUnprocessedNodeAsync()
        {
            var branch = _repositoryFacade.Provide().CachedUrls.GetAllBranches().
                SingleOrDefault(b => b.AugmentationState != CitilinkNodeAugmentationState.Processed);
            return Map(branch);
        }

        public async Task<CitilinkNode> GetRootAsync()
        {
            var extractionState = _repositoryFacade.Provide();
            var tree = extractionState.CachedUrls;
            return Map(tree.Root);
        }

        public async Task RecreateTreeAsync()
        {
            CitilinkBranch root = new(0, mainCatalogUrl, [], false, CitilinkNodeType.RootCatalog,
                CitilinkNodeAugmentationState.PartiallyProcessed_TypeIsKnown);
            CatalogUrlsTree tree = new(root);
            CitilinkExtractionStateDto extractionState = new(tree, false);
            _repositoryFacade.Save(extractionState);
        }


        private static CitilinkNode Map(CitilinkBranch branch)
        {
            CitilinkScrapeTarget target = new(branch.Url);
            CitilinkNode node = new(target, branch.AugmentationState, branch.NodeType,
                branch.Children.Select(Map).ToList(), branch.DescendantsProcessed);
            return node;
        }

        private static CitilinkBranch Map(CitilinkNode node, int id = default)
        {
            CitilinkBranch branch = new(id, node.DefaultLocation.Url,
                node.Descendants.Select(Map).ToList(), node.DescendantsProcessed,
                node.NodeType, node.AugmentationState);
            return branch;
        }


        public async Task UpdateNodeAsync(CitilinkNode node)
        {
            var extractionState = _repositoryFacade.Provide();
            var matchingBranch = extractionState.CachedUrls.GetAllBranches().
                Where(b => b.Url == node.DefaultLocation.Url).Single();
            _repositoryFacade.UpdateBranch(matchingBranch);
        }
    }
}
