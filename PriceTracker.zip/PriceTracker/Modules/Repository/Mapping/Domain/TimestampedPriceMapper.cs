﻿using PriceTracker.Core.Models.Domain;
using PriceTracker.Modules.Repository.Entities.Domain;

namespace PriceTracker.Modules.Repository.Mapping.Domain
{
    public class TimestampedPriceMapper : BaseGenericCoreToEntityMapper<TimestampedPriceDto,
        TimestampedPriceEntity>, ITimestampedPriceMapper
    {
        public TimestampedPriceMapper() : base()
        {

        }


        protected override TimestampedPriceEntity CreateEntityFromModel(TimestampedPriceDto model)
        {
            TimestampedPriceEntity entity = new(model.Price, model.DateTime.ToUniversalTime(), model.Id);
            entity.MerchPriceHistoryId = model.MerchPriceHistoryId;
            return entity;
        }

        protected override TimestampedPriceDto CreateModelFromEntity(TimestampedPriceEntity entity)
        {
            return new TimestampedPriceDto(entity.Id, entity.Price, entity.DateTime.ToLocalTime(),
                entity.MerchPriceHistoryId);
        }

        protected override void MapModelFieldsToEntity(TimestampedPriceDto model, TimestampedPriceEntity entity)
        {
            entity.Price = model.Price;
            entity.MerchPriceHistoryId = model.MerchPriceHistoryId;
            entity.DateTime = model.DateTime.ToUniversalTime();
        }
    }
}
