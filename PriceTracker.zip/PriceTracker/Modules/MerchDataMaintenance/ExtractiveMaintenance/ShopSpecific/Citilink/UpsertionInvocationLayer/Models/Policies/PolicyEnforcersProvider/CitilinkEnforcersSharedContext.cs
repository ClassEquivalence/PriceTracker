﻿namespace PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.UpsertionInvocationLayer.Models.Policies.PolicyEnforcersProvider
{
    public class CitilinkEnforcersSharedContext
    {
        // What's request in this context?
        public int MaxRequestsPerScrapeEpisode;
        public int MaxRequestsPerPartialCycle;

        public int RequestsPerPartialCycleRemainingQuota;

        public CitilinkEnforcersSharedContext(int maxRequestsPerScrapeEpisode = 5,
            int maxRequestsPerPartialCycle = 200)
        {
            ArgumentOutOfRangeException.ThrowIfNegativeOrZero(maxRequestsPerPartialCycle);
            ArgumentOutOfRangeException.ThrowIfNegativeOrZero(maxRequestsPerScrapeEpisode);
            MaxRequestsPerScrapeEpisode = maxRequestsPerScrapeEpisode;
            MaxRequestsPerPartialCycle = maxRequestsPerPartialCycle;
            RequestsPerPartialCycleRemainingQuota = MaxRequestsPerPartialCycle;
        }

    }
}
