﻿using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.CoordinationLayer;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.UpsertionInvocationLayer.Models.Policies.PolicyEnforcersProvider;

namespace PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.ShopSpecific.Citilink.UpsertionInvocationLayer
{

    public enum PartialCycleState
    {
        PartialCompleted,
        FullCompleted
    }
    public interface ICitilinkUpsertionInvoker
    {
        Task<PartialCycleState> ExecutePartialCycleAsync(CitilinkEnforcersSharedContext cycleQuota);

    }
}
