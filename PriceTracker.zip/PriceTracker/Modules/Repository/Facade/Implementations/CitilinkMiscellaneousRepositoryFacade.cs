﻿using PriceTracker.Core.Models.Infrastructure;
using PriceTracker.Core.Models.Process.ShopSpecific.Citilink.ExtractionState;
using PriceTracker.Core.Models.Process.ShopSpecific.Citilink.ExtractionState.CatalogTree;
using PriceTracker.Modules.Repository.Facade.Citilink;
using PriceTracker.Modules.Repository.Repositories.ShopSpecific.Citilink;

namespace PriceTracker.Modules.Repository.Facade.Implementations
{
    public class CitilinkMiscellaneousRepositoryFacade : ICitilinkMiscellaneousRepositoryFacade
    {
        private readonly CitilinkExtractorStorageStateRepository
            _citilinkExtractorStorageStateRepository;
        private readonly CitilinkExtractionStateRepository
            _citilinkParsingExecutionStateRepository;

        public CitilinkMiscellaneousRepositoryFacade(
            CitilinkExtractorStorageStateRepository citilinkStorageStateRepository,
            CitilinkExtractionStateRepository citilinkExtractionStateRepository)
        {
            _citilinkExtractorStorageStateRepository = citilinkStorageStateRepository;
            _citilinkParsingExecutionStateRepository = citilinkExtractionStateRepository;
        }

        public CitilinkExtractorStorageStateDto? GetExtractorStorageState()
        {
            return _citilinkExtractorStorageStateRepository.
                Get();
        }

        public CitilinkExtractionStateDto? Provide()
        {
            return _citilinkParsingExecutionStateRepository.Get();
        }

        public void Save(CitilinkExtractionStateDto info)
        {
            _citilinkParsingExecutionStateRepository.Set(info);
        }

        public void SetExtractorStorageState(CitilinkExtractorStorageStateDto storageStateDto)
        {
            _citilinkExtractorStorageStateRepository.
                Set(storageStateDto);
        }

        /// <summary>
        /// Updateable branch should have parent.
        /// </summary>
        /// <param name="branch"></param>
        public void UpdateBranch(CitilinkBranch branch)
        {
            var extractionState = Provide();
            var extractionStateTree = extractionState.CachedUrls;
            var parent = extractionStateTree.GetAllBranches().
                Single(b => b.Id == branch.ParentId);

            var removable = parent.Children.Single(b => b.Id == branch.Id);
            parent.Children.Remove(removable);
            parent.Children.Add(branch);

            Save(extractionState);
        }
    }
}
