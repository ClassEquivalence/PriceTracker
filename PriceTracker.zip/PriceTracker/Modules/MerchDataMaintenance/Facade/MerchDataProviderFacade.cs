﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using PriceTracker.Core.Configuration.ProvidedWithDI;
using PriceTracker.Core.Configuration.ProvidedWithDI.Options;
using PriceTracker.Modules.MerchDataMaintenance.ExtractiveMaintenance.Common.CommonLayers.CoordinationLayer;


/*
 Сделать передачу в репозиторий состояния выполнения
 Да и вообще зарефакторить весь модуль надо бы.
 */
namespace PriceTracker.Modules.MerchDataMaintenance.Facade
{
    /// <summary>
    /// Точка взаимодействия с модулем, и модуля - с внешним окружением.
    /// </summary>
    public class MerchDataProviderFacade : IMerchDataProviderFacade
    {
        private UpsertionService _scheduledUpserter;
        private readonly ILogger _logger;
        private readonly MerchUpsertionOptions _options;
        private readonly IAppEnvironment _appEnvironment;

        public MerchDataProviderFacade(ILogger<Program> logger,
            IOptions<MerchUpsertionOptions> options, IAppEnvironment appEnvironment,
            UpsertionService upsertionService)
        {
            _options = options.Value;
            _appEnvironment = appEnvironment;

            _logger = logger;

            _scheduledUpserter = upsertionService;



        }

        public async Task ProcessMerchUpsertion()
        {
            _logger.LogInformation($"{nameof(MerchDataProviderFacade)}: " +
                $"Запущен процесс upsert'а товаров.");

            if (_appEnvironment.IsDevelopment)
            {
                await _scheduledUpserter.ProcessUpsertion();
            }
            else
            {
                try
                {
                    await _scheduledUpserter.ProcessUpsertion();
                }
                catch (DbUpdateException ex)
                {
                    _logger.LogError(ex.Message);
                    _logger.LogError(ex.InnerException?.Message);
                }
            }

        }

        public async Task OnShutdownAsync()
        {
            await _scheduledUpserter.OnShutdown();

        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            if (_options.UpsertionActive)
            {
                /*
                var citilinkOptions = _options.CitilinkUpsertionOptions;
                CitilinkMerchDataUpserter consumer = new(_citilinkMerchRepository, 
                    _shopSelector.GetCitilinkShop(), logger: _logger);
                var CitilinkStorageState = _citilinkMiscellaneousRepository.
                GetExtractorStorageState();
                GUICitilinkExtractor extractor = new(new(), citilinkOptions, _options.UserAgent, _logger);

                ScheduledCitilinkMerchUpserter
                    scheduledCitilinkMerchUpserter = new(consumer, extractor, TimeSpan.
                    FromDays(citilinkOptions.CitilinkPriceUpdatePeriod), _appEnvironment,
                    DateTime.Now, _citilinkMiscellaneousRepository, _logger, 
                    TimeSpan.FromHours(citilinkOptions.MinCooldownForPageRequests));

                _scheduledUpserter = new([scheduledCitilinkMerchUpserter]);
                */
                // TODO: Костыль? Не изучено, как должен работать StartAsync и взаимодействовать
                // с CancellationToken.
                ProcessMerchUpsertion();
            }
            else
            {
                _logger?.LogInformation($"{nameof(MerchDataProviderFacade)}: Merch upsertion" +
                $" inactive.");
            }
        }

        public async Task StopAsync(CancellationToken cancellationToken)
        {
            _logger?.LogInformation($"{nameof(MerchDataProviderFacade)}: shutdown" +
                $"process started.");
            if (_options.UpsertionActive)
            {

                await OnShutdownAsync();
                _logger?.LogInformation($"{nameof(MerchDataProviderFacade)}: shutdown" +
                   $"process completed.");
            }

        }
    }
}
